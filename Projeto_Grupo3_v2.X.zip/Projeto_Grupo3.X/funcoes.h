/* 
 * File:                funcoes.h  
 * Author:              Herbert Tavares, Julio Cesar Carvalhes, Victhor Alexandre, Yuri Virginio
 * Comments:            -- // --
 * Revision history:    2.00
 */

#ifndef FUNCOES_H
#define	FUNCOES_H

#include <xc.h> // include processor files - each processor file is guarded.  

//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Carrega o valor do Ciclo �til no PWM
 * @param   dutyValue
 * @return  ---
 */
void setPwm(uint16_t dutyValue);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Interrup��o do Motor de Passo.
 * @param   ---
 * @return  ---
 */
void interrupt_MotorDePasso(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Passos do Motor de Passo
 * @param   posicaoAtual, posicaoDesejada
 * @return  ---
 */
void Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Calculo de Erro do Controle P.I.
 * @param   ---
 * @return  ---
 */
void calcularErro(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Saida do Controlador 
 * @param   ---
 * @return  ---
 */
void calcularSaidaControlador(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Arammzenar os valores do Controlador
 * @param   ---
 * @return  ---
 */
void guardarValoresDoControlador(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Transmiss�o de Dados na USART
 * @param   ---
 * @return  ---
 */
void EnviaTX(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Reinicio do Quadro de Comunica��o (Ponteiro = 0)
 * @param   ---
 * @return  ---
 */
void ReiniciaQuadro(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Analisa os dados que foram recebidos do quadro de comunica��o RX.
 * @param   ---
 * @return  ---
 */
void ProcessaDados(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Maquina de Estado finito 
 * @param   ---
 * @return  ---
 */
void Maquina();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Aquisi��o da Temperatura e Velocidade do Som
 * @param
 * @return
 */
void Temperatura_e_VelocidadeSom(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Aquisi��o da Posi��o da Bola no Tubo
 * @param   ---
 * @return  ---
 */
void Posicao_Bola_Tubo(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Recep��o dos dados 
 * @param   ---
 * @return  ---
 */
void EUSART_RxBuffer(void);

void Medicao_Distancia_Trigger(void);

void EUSART_TxBuffer(void);

uint16_t Media(uint16_t Time);
#endif	/* FUNCOES_H */
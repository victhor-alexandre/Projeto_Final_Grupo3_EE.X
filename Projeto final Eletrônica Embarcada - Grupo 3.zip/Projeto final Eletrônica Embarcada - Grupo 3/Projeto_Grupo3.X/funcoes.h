/* 
 * File:                funcoes.h  
 * Author:              Herbert Tavares, Julio Cesar Carvalhes, Victhor Alexandre, Yuri Virginio
 * Comments:            -- // --
 * Revision history:    2.00
 */

#ifndef FUNCOES_H
#define	FUNCOES_H

#include <xc.h> // include processor files - each processor file is guarded.  

//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Carrega o valor do Ciclo �til no PWM
 * @param   dutyValue
 * @return  ---
 */
void setPwm(uint16_t dutyValue);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Interrup��o do Motor de Passo.
 * @param   ---
 * @return  ---
 */
void interrupt_MotorDePasso(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Passos do Motor de Passo
 * @param   posicaoAtual, posicaoDesejada
 * @return  ---
 */
void Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Calculo de Erro do Controle P.I.
 * @param   ---
 * @return  ---
 */
void calcularErro(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Saida do Controlador 
 * @param   ---
 * @return  ---
 */
void calcularSaidaControlador(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Arammzenar os valores do Controlador
 * @param   ---
 * @return  ---
 */
void guardarValoresDoControlador(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Transmiss�o de Dados na USART
 * @param   ---
 * @return  ---
 */
void EnviaTX(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Analisa os dados que foram recebidos do quadro de comunica��o RX.
 * @param   ---
 * @return  ---
 */
void ProcessaDados(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * Maquina de Estado finito 
 * @param   ---
 * @return  ---
 */
void Maquina();
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Aquisi��o da Temperatura e Velocidade do Som
 * @param
 * @return
 */
void Temperatura_e_VelocidadeSom(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Aquisi��o da Posi��o da Bola no Tubo
 * @param   ---
 * @return  ---
 */
void Posicao_Bola_Tubo(void);
//------------------------------------------------------------------------------------------------------------------------------------------------------
/**
 * @brief Recep��o dos dados 
 * @param   ---
 * @return  ---
 */
void EUSART_RxBuffer(void);

/**
 * @brief Ativa o sinal de trigger por 15 us
 */
void Medicao_Distancia_Trigger(void);

/**
 * @brief Carrega o buffer de envio (Tx) com as informa��es
 */
void EUSART_TxBuffer(void);


/**
 * @brief Calcula a m�dia das 4 �ltimas medi��es de dist�ncia
 * @param Time
 * @return M�dia calculada
 */
uint16_t Media(uint16_t Time);

#endif	/* FUNCOES_H */
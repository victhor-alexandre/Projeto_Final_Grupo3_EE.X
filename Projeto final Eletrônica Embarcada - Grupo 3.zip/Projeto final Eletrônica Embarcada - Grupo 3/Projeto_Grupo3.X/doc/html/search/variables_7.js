var searchData=
[
  ['saidaanterior_0',['SaidaAnterior',['../main_8h.html#a4a61335ca356875982ad6e64aa71470a',1,'main.h']]],
  ['saidacontrolador_1',['SaidaControlador',['../main_8h.html#a6cf60bf6d26d0bc694fb9bd246275b0a',1,'main.h']]],
  ['setpoint_2',['Setpoint',['../main_8h.html#acfa3eadc9e2b75063b1026b5a111ab02',1,'main.h']]]
];

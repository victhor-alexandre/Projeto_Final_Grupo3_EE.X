var searchData=
[
  ['passo_0',['Passo',['../funcoes_8c.html#ae11b904a0c165caa025cf07062e7b5bd',1,'Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada):&#160;funcoes.c'],['../funcoes_8h.html#ae11b904a0c165caa025cf07062e7b5bd',1,'Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada):&#160;funcoes.c']]],
  ['posicao_5fbola_5ftubo_1',['Posicao_Bola_Tubo',['../funcoes_8c.html#a22b9867b3156b311c0e634ed74b59322',1,'Posicao_Bola_Tubo():&#160;funcoes.c'],['../funcoes_8h.html#a0eb849aa4a8336d8dee08ca6f262ede3',1,'Posicao_Bola_Tubo(void):&#160;funcoes.c']]],
  ['posicaovalvula_2',['posicaoValvula',['../main_8h.html#ade5c7f437e63e077709395d47bf5529d',1,'main.h']]],
  ['processadados_3',['ProcessaDados',['../funcoes_8c.html#a86767fd295ef20d6fafde0e9b33e66a5',1,'ProcessaDados():&#160;funcoes.c'],['../funcoes_8h.html#a432ca96314b10684705d13f9d8fbbd4c',1,'ProcessaDados(void):&#160;funcoes.c']]],
  ['proximaposicao_4',['proximaPosicao',['../main_8h.html#af9f382949ff95f57d0fbe38bc99ec20b',1,'main.h']]]
];

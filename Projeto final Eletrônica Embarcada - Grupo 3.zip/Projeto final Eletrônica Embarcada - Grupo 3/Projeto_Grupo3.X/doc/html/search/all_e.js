var searchData=
[
  ['v_5fsom_0',['v_som',['../main_8h.html#a037d19087d62cb327fc08d67c9e386c3',1,'main.h']]]
];

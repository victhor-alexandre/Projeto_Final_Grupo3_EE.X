var searchData=
[
  ['flagcontrole_0',['flagControle',['../main_8h.html#abf83699db65a6575cb5a3f4bc09bf4ea',1,'main.h']]],
  ['fullframe_1',['fullFrame',['../main_8h.html#adcc0b01b8bf34752bf26f8e04a1bda8a',1,'main.h']]]
];

var searchData=
[
  ['temp_0',['temp',['../main_8h.html#ac367d9ce50d18409b1d4ec83260a7288',1,'main.h']]],
  ['tempo_5fs_1',['tempo_s',['../main_8h.html#a8ed148bcea871c2003fe2a5baf51ed88',1,'main.h']]],
  ['tipocontrole_2',['tipoControle',['../main_8h.html#a3f35d40b8dd7a5ae23b4cb8bf6e04624',1,'main.h']]],
  ['tupvt_3',['TUPVT',['../main_8h.html#aabc95cbf445ea80100ff4c664c34a18c',1,'main.h']]],
  ['txbuffer_4',['TxBuffer',['../main_8h.html#a224f58a7ca378535b22f7c73418aec08',1,'main.h']]]
];

var searchData=
[
  ['resetpasso_0',['resetPasso',['../main_8h.html#a8e48a950b3a80fda6276d138887bcadc',1,'main.h']]],
  ['rxbuffer_1',['RxBuffer',['../main_8h.html#a401c01d416ee721954ba8d48a1ad5548',1,'main.h']]],
  ['rxindex_2',['RxIndex',['../main_8h.html#a87937073f83feeb6a6cd5f1b4fa9e16f',1,'main.h']]]
];

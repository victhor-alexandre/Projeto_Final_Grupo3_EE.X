var searchData=
[
  ['mediatempo_0',['mediaTempo',['../main_8h.html#a61c26ea041a86ce290a5967af93bbbb9',1,'main.h']]],
  ['modo_1',['modo',['../main_8h.html#a4ceb7b469580c9ef2afa9cfcc286a06c',1,'main.h']]],
  ['modocontrole_2',['modoControle',['../main_8h.html#af204ee78e32a0fa9cf93b68b7fdfccb2',1,'main.h']]]
];

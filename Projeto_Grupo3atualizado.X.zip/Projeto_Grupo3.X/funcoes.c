#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "funcoes.h"



//------------------------------------------------------------------------------------------------------------------------------------
// Ciclo �til do PWM
//----------------------------------
void setPwm(uint16_t dutyValue){                                //< Recebe o valor do pwm
    EPWM1_LoadDutyValue(dutyValue);                             //< Carrega o Ciclo �til atrav�s da Fun��o
}


//------------------------------------------------------------------------------------------------------------------------------------
// Controle do motor de passo
//----------------------------------
// O motor de passo ser� controlado pela interrup��o de um timer de 5ms.
// Cada interrup��o, o controlador verifica se o motor j� chegou na posi��o desejada, e se n�o, avan�a um �nico passo na dire��o em quest�o
// Necess�rio 1 controle de dire��o, um contador, um booleano para inicializar o motor.
void interrupt_MotorDePasso(void){                              //< Ativado a cada 5ms
    static uint16_t posicaoValvulaReset = MAX_PASSO;            //< Essa vari�vel ser� decrementada e enviada ao motor de passo, at� que ele desative o sensor
    if(!resetPasso){                                             //< Se o reset estiver habilitado (resetPasso = 1))
        if(!CMP1_GetOutputStatus()){                                           //< Se o sensor estiver em 1
            Passo(posicaoValvulaReset, 0);                      //< D� um passo para abrir a valvula
            posicaoValvulaReset--;
        }else{                                                  //< Se o sensor estiver em 0
            resetPasso = 1;                                     //< Desliga o reset
            posicaoValvula = 0;                            //< Agora a posi��o padr�o � zerada
            posicaoValvulaReset = MAX_PASSO;                    //< Essa variavel � resetada em 450 para um futuro reset
        }
    }else{                                                      //< Se o reset estiver desabilitado
                                                                //< Atualiza a posicao atual da v�lvula e depois d� um passo.
        if(posicaoValvula > proximaPosicao){
            if(posicaoValvula>0) posicaoValvula--;
        }else if (posicaoValvula < proximaPosicao){
            if(posicaoValvula<MAX_PASSO) posicaoValvula++;
        }
        if (proximaPosicao > MAX_PASSO) proximaPosicao = MAX_PASSO;
        Passo(posicaoValvula, proximaPosicao);                  //< D� um passo de acordo com as posi��es atuais e desejada
    }
    
    Medicao_Distancia_Trigger();        //ativando o trigger uma vez a cadapasso do motor de passo
}                                

void Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada){
    static uint8_t i;
    SM1_SetLow();
    SM2_SetLow();
    SM3_SetLow();
    SM4_SetLow();
    
    if(posicaoAtual > posicaoDesejada){
        i = (i<=0) ? 3 : (i-1);                     //< Decrementa i, se i = 0, ent�o volta para i=3
    }else if (posicaoAtual < posicaoDesejada){
        i = (i>=3) ? 0 : (i+1);                     //< Incrementa i, se i = 3, ent�o volta para i=0
    }else{
        i=4;                                        //< Se estiver na posi��o desejada, n�o entra em nenhum dos cases (o motor de passo fica desligado)
    }
    
    switch(i){
        case 3:
            SM1_SetHigh();
            SM2_SetHigh();
            break;
        case 2:
            SM2_SetHigh();
            SM3_SetHigh();
            break;
        case 1:
            SM3_SetHigh();
            SM4_SetHigh();
            break;
        case 0:
            SM4_SetHigh();
            SM1_SetHigh();
            break;
    }
    
}



//------------------------------------------------------------------------------------------------------------------------------------
// rotina de controle
//----------------------------------
// Modelo PI (proporcional-integrador)
// Deve controlar ou o pwm, ou o motor de passo
// faz parte da m�quina de estados. Ou seja, deve ser bypassed quando um dos modos de controle estiver inativo

void calcularErro(void){
    Erro = (int)(Setpoint - D_mm.Dado);        //Erro(k) = sp(K) - y(K)
}

void calcularSaidaControlador(void){
    SaidaControlador = ((sinal*Kc)*((Erro - Erro_1)+(T/Ti)*((Erro+Erro_1)/2)));
    SaidaControlador = SaidaControlador + SaidaAnterior;
    //limitando a sa�da
    if((int)(SaidaControlador) < 0){
        SaidaControlador = 0;
    }else if((int)(SaidaControlador) > limite){
        SaidaControlador = limite;
    }
    if(tipoControle){
        proximaPosicao = (uint16_t)(SaidaControlador);
    }else{
        dutyValue = (uint16_t)(SaidaControlador);
        setPwm(dutyValue);
    }
}

void guardarValoresDoControlador(void){
    Erro_1 = Erro;
    SaidaAnterior = SaidaControlador;
}



//------------------------------------------------------------------------------------------------------------------------------------
// Aquisi�ao da Temperatura e Velocidade do Som
//----------------------------------
// Realiza-se a aquisi��o da Temperatura com uma precis�o de varia��o de 1�C.
// Com o valor da Temperatura � o valor correspondente da velocidade do som na tabela armazenada na Mem�ria EEPROM.
 
void Temperatura_e_VelocidadeSom(){
    
    temp.Dado = (uint16_t)((ADC_GetConversion(8)));    //< temp = valor do adc x resolu��o ((50-2)/1024) + 273
    v_som = TUPVT[temp.Dado/10];                                          //Para c�lculo da velocidade do som

}

void Posicao_Bola_Tubo(){
    //Vari�vel respons�vel por transformar o tempo em unidades de engenharia (segundos)
    tempo_s = TMR1_ReadTimer();         //Base de tempo em us (a cada incremento do timer corresponde a 1us.)
    mediaTempo = Media(tempo_s);
    //C�lculo da dist�ncia em mil�metros
    D_mm.Dado = (uint16_t)(((uint24_t)(v_som) * (uint24_t)(mediaTempo)) / 2000);       
    TMR1_WriteTimer(0);
    
    
}

void Medicao_Distancia_Trigger(void){
    TRIGGER_SetHigh();
    __delay_us(15);
    TRIGGER_SetLow();
    
    flagControle = 1;
}
//------------------------------------------------------------------------------------------------------------------------------------
// Comunica��o Serial RX e TX
//----------------------------------
// Recebimento de dados no quadro de comunica��o.
// 40 ms sem receber dados, reinicia o quadro.
// 7 Bytes de Recep��o e 13 Bytes de Transmiss�o
// A cada 100ms envia dados.
void EUSART_RxBuffer(){
    RxBuffer[RxIndex++] = RCREG;
    if(sizeof(RxBuffer) <= RxIndex)
    {
        RxIndex = 0;
        fullFrame = true;
    }
    TMR6_WriteTimer(0); 
    
}

void ProcessaDados(){
    modo              = RxBuffer[0];
    if ((modo >= 0) | (modo<=3)){       //s� carrega as vari�veis com os Buffers se o comando for v�lido
        Setpoint          =(RxBuffer[1] << 8)| RxBuffer[2];   
        proximaPosicao    =(RxBuffer[3] << 8)| RxBuffer[4];
        dutyValue         =(RxBuffer[5] << 8)| RxBuffer[6];
    }
    fullFrame = false;
    
    switch(modo){
        case 0: 
            //fun��o manual (apenas ativa o pwm e o motor de passo no valor recebido)
            //como o motor de passo funciona por interrup��o, n�o � necess�rio chamar a fun��o dele aqui, apenas alterar o valor proximaPosicao
            setPwm(dutyValue);
            modoControle = 0;       //modo de controle desativado
            Setpoint = 0;           //desprezando o setpoint recebido pelo eusart
        break;
        case 1: 
            // fun��o para setar um valor do passo e o controle ira�ajustar o PWM para atingir o set point de altura
            dutyValue = 0;          //zerando o duty value que foi escrito na recep��o do EUSART
            SaidaAnterior = 0;      //o controlador come�a com a sa�da em 0
            modoControle = 1;       //controlador ativado
            tipoControle = 0;       //modo de controle do pwm
            break;
        case 2: 
             // fun��o para setar um valor do PWM e o controle ira�ajustar a ventoinha para atingir o set point de altura
            setPwm(dutyValue);
            proximaPosicao = 0;     //zerando a posi��o do passo que foi escrita na recep��o do EUSART
            SaidaAnterior = 0;      //o controlador come�a com a sa�da em 0
            modoControle = 1;       //controlador ativado
            tipoControle = 1;       //modo de controle do motor de passo
        break;
        case 3: 
            RESET(); // Reinicia o PIC
        break;
        default:
            break;
    }
}
    
void EnviaTX(){
   
    for(uint8_t i=0; i<15; i++){
        EUSART_Write(TxBuffer[i]);
    }
    
    
    
}

void ReiniciaQuadro(){
    RxIndex = 0;
}

void EUSART_TxBuffer(){
    
   TxBuffer[0] = modo;//Modo de Opera��o 
   TxBuffer[1] = (Setpoint & 0xFF00) >> 8; //Setpoint de Altura.b1
   TxBuffer[2] = (Setpoint & 0x00FF);//SetPoint de Altura.b0
   TxBuffer[3] = D_mm.b1; //Medi�ao de altura.b0
   TxBuffer[4] = D_mm.b0; //Medi�ao de altura.b1
   TxBuffer[5] = (mediaTempo & 0xFF00) >> 8; //Tempo.b1
   TxBuffer[6] = (mediaTempo & 0x00FF) ; //Tempo.b0
   TxBuffer[7] = temp.b1; //Temperatura.b0
   TxBuffer[8] = temp.b0; //Temperatura.b1
   TxBuffer[9] = (proximaPosicao & 0xFF00) >> 8; //Setpoint de Valvula.b1
   TxBuffer[10] = (proximaPosicao & 0x00FF); //Setpoint de Valvula.b0
   TxBuffer[11] = (posicaoValvula & 0xFF00) >> 8; //Posi��o Valvula.b1
   TxBuffer[12] = (posicaoValvula & 0x00FF); //Posi��o Valvula.b0
   TxBuffer[13] = (dutyValue & 0xFF00) >> 8 ; //Ciclo Util Motor.b1
   TxBuffer[14] = (dutyValue & 0x00FF); //Ciclo Util Motor.b0
           
}



//------------------------------------------------------------------------------------------------------------------------------------
// M�quina de Estado Finito 
//----------------------------------
// Atua��o nos modos de Opera��o

void Maquina(){
    
            Temperatura_e_VelocidadeSom();
            //Posicao_Bola_Tubo();
            //
            //Calcular a  m�dia  das ultimas quatro medi�oes
            //
            //Controle
            if(modoControle & flagControle){
                calcularErro();
                calcularSaidaControlador();
                guardarValoresDoControlador();
                flagControle = 0;               //zerando a flag para s� calcular ap�s a pr�xima medi��o
            }

            //

            EUSART_TxBuffer(); 
            
    }


uint16_t Media(uint16_t Time){
    static uint8_t i=0;
    uint16_t Media;
    static uint16_t bufferTempo[4];
    i = (i==3) ? 0 : (i+1);
    bufferTempo[i] = Time;
    Media = (bufferTempo[0] + bufferTempo[1] + bufferTempo[2] + bufferTempo[3])/4;
    return Media;
}
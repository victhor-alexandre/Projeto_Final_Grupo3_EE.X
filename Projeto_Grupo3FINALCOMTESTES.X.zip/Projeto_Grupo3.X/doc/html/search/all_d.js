var searchData=
[
  ['t_0',['T',['../main_8h.html#a0acb682b8260ab1c60b918599864e2e5',1,'main.h']]],
  ['temp_1',['temp',['../main_8h.html#ac367d9ce50d18409b1d4ec83260a7288',1,'main.h']]],
  ['temperatura_5fe_5fvelocidadesom_2',['Temperatura_e_VelocidadeSom',['../funcoes_8c.html#a005ef4e773a3df9c845532d2ae9a14e9',1,'Temperatura_e_VelocidadeSom():&#160;funcoes.c'],['../funcoes_8h.html#ad99006d02437615dac83b2c2bdb34628',1,'Temperatura_e_VelocidadeSom(void):&#160;funcoes.c']]],
  ['tempo_5fs_3',['tempo_s',['../main_8h.html#a8ed148bcea871c2003fe2a5baf51ed88',1,'main.h']]],
  ['ti_4',['Ti',['../main_8h.html#a5bb6f8d7057f4e3bcc9b2aa8ea7bfe2f',1,'main.h']]],
  ['tipocontrole_5',['tipoControle',['../main_8h.html#a3f35d40b8dd7a5ae23b4cb8bf6e04624',1,'main.h']]],
  ['tupvt_6',['TUPVT',['../main_8h.html#aabc95cbf445ea80100ff4c664c34a18c',1,'main.h']]],
  ['txbuffer_7',['TxBuffer',['../main_8h.html#a224f58a7ca378535b22f7c73418aec08',1,'main.h']]]
];

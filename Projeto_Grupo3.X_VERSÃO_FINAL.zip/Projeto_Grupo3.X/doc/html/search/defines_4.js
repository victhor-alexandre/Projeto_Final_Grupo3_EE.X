var searchData=
[
  ['t_0',['T',['../main_8h.html#a0acb682b8260ab1c60b918599864e2e5',1,'main.h']]],
  ['ti_1',['Ti',['../main_8h.html#a5bb6f8d7057f4e3bcc9b2aa8ea7bfe2f',1,'main.h']]]
];

var searchData=
[
  ['posicaovalvula_0',['posicaoValvula',['../main_8h.html#ade5c7f437e63e077709395d47bf5529d',1,'main.h']]],
  ['proximaposicao_1',['proximaPosicao',['../main_8h.html#af9f382949ff95f57d0fbe38bc99ec20b',1,'main.h']]]
];

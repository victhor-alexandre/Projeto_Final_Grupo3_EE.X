var searchData=
[
  ['kc_0',['Kc',['../main_8h.html#a1538f83ac50188ab1deadf7790e0d4bc',1,'main.h']]]
];

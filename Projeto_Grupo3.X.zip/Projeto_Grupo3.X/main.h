/* 
 * File:                main.h  
 * Author:              Herbert Tavares, Julio Cesar Carvalhes, Victhor Alexandre, Yuri Virginio
 * Comments:            -- // --
 * Revision history:    2.00
 */

#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> // include processor files - each processor file is guarded.


//Definindo Constantes-----------------------------------------------------------------------------------------------------------------

#define Kc ((tipoControle) ? (0.03) : (0.03))
#define T ((tipoControle) ? (1) : (1)) //                                    
#define Ti ((tipoControle) ? (2) : (2)) //30                                 
#define MAX_PASSO 420                          //< N�mero m�ximo de passos do motor.
#define DELAY_CONTROLE 2000                    //< Delay que ser� aplicado ao controlador. Ao todo, o delay ser� essa vari�vel*3 (em us)
//Definindo Operadores Tern�rios-------------------------------------------------------------------------------------------------------

#define limite ((tipoControle) ? (420) : (1023))         //limite da sa�da do controlador muda com o tipo de opera��o
                                                         //1023 para o pwm, 420 para o motor de passo
#define sinal  ((tipoControle) ? -1 : 1)     
//como o motor de passo segue opera��o inversa (para aumentar o fluxo de ar, diminui-se a posi��o da v�lvula)
//ent�o invertemos o sinal de Kp com essa vari�vel, de acordo com o modo de opera��o


//Estrutura de dados (Union)-----------------------------------------------------------------------------------------------------------

union{                             //< Uni�o entre 2 bytes de dados.
    uint16_t Dado;                 //< Valor de 16 bits que contem os bytes b1 e b0.
    struct{
        uint8_t b0;                //< Byte b0 LSB 
        uint8_t b1;                //< Byte b1 MSB
    };
}D_mm,     
temp;                      //< Variaveis de Temperatura e Posic�o

//union{                             //< Uni�o entre 2 bytes de dados.
//    uint8_t Total[4];                 //< Valor de 16 bits que contem os bytes b1 e b0.
//    struct{
//        uint8_t t1;                //< Byte b0 LSB 
//        uint8_t t2;                //< Byte b1 MSB
//        uint8_t t3;                //< Byte b0 LSB 
//        uint8_t t4;
//    }t;
//}bufferTempo;       

//Variaveis Globais-------------------------------------------------------------------------------------------------------------------
                  
 

//const float     P_fosc = 0.0000000625;         //< Periodo do clock

bool            fullFrame = false,             //< Flag do quadro de comunica��o de Recep��o Completa
                resetPasso = 0,            //< Flag para resetar a posi��o da Valvula
                modoControle,                  //< 0 = controle desativado, 1 = controle ativado
                tipoControle;                  //< 0 = controle do pwm, 1 = controle do motor de passo

uint16_t        temper,
                SaidaControlador=0,
                SaidaAnterior=0,
                posicaoAtual,
                proximaPosicao,
                dutyValue,
                Setpoint,
                posicaoDesejada,
                posicaoValvula,
                tempo_s = 0,    
                v_som, 
                mediaTempo;

int             Erro    = 0,                   //< Erro calculado no Controle P.I. 
                Erro_1  = 0;                   //< Erro atualizado calclulado no Controle P.I.;                         //< Velocidade do som;                   //< Tempo de voo ;                        //< Temperatura
                

uint8_t         TxBuffer[15],                  //< Buffer de Transmiss�o USART
                RxBuffer[7],                   //< Buffer de Recep��o USART
                modo,                          //< Modo de Opera��o
                RxIndex=0;                     //< Ponteiro do Buffer de Recep��o
                    
uint16_t Tempo, passos, Est_atual;                    // Variavel para armazenar o Tempo do Pulso

                
//Mem�ria EEPROM -----------------------------------------------------------------------------------------------------------------

// Tabela de Velocidades do Som correspondentes �s Temperaturas de 0�C a 50�C 
////__eeprom float TUPVT[]={331.45, 332.05, 332.66, 333.27, 333.87, 334.47, 335.07, 
//335.67, 336.27, 336.87, 337.46, 338.06, 338.65, 339.25, 339.84, 340.43, 341.02, 
//341.61, 342.20, 342.78, 343.37, 343.96, 344.54, 345.12, 345.70, 346.29, 346.87, 
//347.45, 348.02, 348.60, 349.18, 349.75, 350.33, 350.90, 351.47, 352.05, 352.62, 
//353.19, 353.75, 354.32, 354.89, 355.46, 356.02, 356.59, 357.15, 357.71, 358.27, 
//358.83, 359.39, 359.95, 360.51};

__eeprom uint16_t TUPVT[] = {
331, 
332, 
333, 
333, 
334, 
334, 
335, 
336, 
336, 
337, 
337, 
338, 
339, 
339, 
340, 
340, 
341, 
342, 
342, 
343, 
343, 
344, 
345, 
345, 
346, 
346, 
347, 
347, 
348, 
349, 
349, 
350, 
350, 
351, 
351, 
352, 
353, 
353, 
354, 
354, 
355, 
355, 
356, 
357, 
357, 
358, 
358, 
359, 
359, 
360, 
361
};
#endif	/* XC_HEADER_TEMPLATE_H */


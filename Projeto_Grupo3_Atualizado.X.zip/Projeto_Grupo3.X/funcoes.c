#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/tmr6.h"
#include "main.h"
#include "funcoes.h"

//------------------------------------------------------------------------------------------------------------------------------------
// Controle do motor de passo
//----------------------------------
// O motor de passo ser� controlado pela interrup��o de um timer de 5ms.
// Cada interrup��o, o controlador verifica se o motor j� chegou na posi��o desejada, e se n�o, avan�a um �nico passo na dire��o em quest�o
// Necess�rio 1 controle de dire��o, um contador, um booleano para inicializar o motor.

void setPwm(uint16_t dutyValue){     //recebe o valor do pwm
    EPWM1_LoadDutyValue(dutyValue);
}

void interrupt_MotorDePasso(void){      //ativado a cada 5ms
    static uint16_t posicaoValvulaReset = MAX_PASSO;       //essa vari�vel ser� decrementada e enviada ao motor de passo, at� que ele desative o sensor
    if(resetPasso){     //se o reset estiver habilitado (resetPasso = 1))
        if(Lim_PORT){       //se o sensor estiver em 1
            Passo(posicaoValvulaReset, 0);      //d� um passo para abrir a valvula
            posicaoValvulaReset--;
        }else{              //se o sensor estiver em 0
            resetPasso = 0;             //desliga o reset
            posicaoValvula = 0;         //agora a posi��o padr�o � zerada
            posicaoValvulaReset = MAX_PASSO;  //essa variavel � resetada em 450 para um futuro reset
        }
    }else{      //se o reset estiver desabilitado
        //atualiza a posicao atual da v�lvula e depois d� um passo.
        if(posicaoValvula > proximaPosicao){
            if(posicaoValvula>0) posicaoValvula--;
        }else if (posicaoValvula < proximaPosicao){
            if(posicaoValvula<MAX_PASSO) posicaoValvula++;
        }
        Passo(posicaoValvula, proximaPosicao);     //d� um passo de acordo com as posi��es atuais e desejada
    }
}

void Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada){
    static uint8_t i;
    SM1_SetLow();
    SM2_SetLow();
    SM3_SetLow();
    SM4_SetLow();
    
    if(posicaoAtual > posicaoDesejada){
        i = (i==0) ? 3 : (i-1);       //decrementa i, se i = 0, ent�o volta para i=3
    }else if (posicaoAtual < posicaoDesejada){
        i = (i==3) ? 0 : (i+1);       //incrementa i, se i = 3, ent�o volta para i=0
    }
    
    switch(i){
        case 3:
            SM1_SetHigh();
            SM2_SetHigh();
            break;
        case 2:
            SM2_SetHigh();
            SM3_SetHigh();
            break;
        case 1:
            SM3_SetHigh();
            SM4_SetHigh();
            break;
        case 0:
            SM4_SetHigh();
            SM1_SetHigh();
            break;
    }
    
}

//------------------------------------------------------------------------------------------------------------------------------------
// rotina de controle
// Modelo PI (proporcional-integrador)
// Deve controlar ou o pwm, ou o motor de passo
// faz parte da m�quina de estados. Ou seja, deve ser bypassed quando um dos modos de controle estiver inativo

void calcularErro(void){
    Erro = Setpoint - Distancia;        //Erro(k) = sp(K) - y(K)
}

void calcularSaidaControlador(void){
    SaidaControlador = (float)(sinal*Kc)*((Erro - Erro_1)+(T/Ti)*((Erro+Erro_1)/2)) + (float)(SaidaAnterior);
    
    //limitando a sa�da
    if(SaidaControlador < 0.0){
        SaidaControlador = 0.0;
    }else if(SaidaControlador > limite){
        SaidaControlador = limite;
    }
}

void guardarValoresDoControlador(void){
    Erro_1 = Erro;
    SaidaAnterior = SaidaControlador;
}

//------------------------------------------------------------------------------------------------------------------------------------
//Fun��o respons�vel por inicializar a medi��o da dist�ncia a partir da habilita��o do trigger
void Medicao_Distancia_Trigger(){

    TRIGGER_SetHigh();
    __delay_us(15);
    TRIGGER_SetLow(); 
}

void Temperatura_e_VelocidadeSom(){
    //Fazendo a convers�o do valor de temperatura para unidades de engenharia
    // temp = valor do adc x resolu��o (50/1024) + 273
    temperatura.Dado = (uint16_t)((float)ADC_GetConversion(8) * 0.048);
    //Para c�lculo da velocidade do som
    v_som = TUPVT[temper];

}

// Fun��o de c�lculo da posi��o da bola no tubo
void Posicao_Bola_Tubo(){
    Temperatura_e_VelocidadeSom();
    //Vari�vel de contagem do temporizador par envio serial
    contagem_temporizador.Dado = TMR1_ReadTimer();
    //Vari�vel respons�vel por transformar o tempo em unidades de engenharia (segundos)
    tempo_segundos.Dado = (uint16_t)(TMR1_ReadTimer() * P_fosc);
    //C�lculo da dist�ncia em mil�metros
    D_mm.Dado = (uint16_t)(v_som * (tempo_segundos.Dado / 2)*1000);
    TMR1_WriteTimer(0);
    
}

//------------------------------------------------------------------------------------------------------------------------------------

void EUSART_RxBuffer(){
    RxBuffer[RxIndex++] = RCREG;
    if(sizeof(RxBuffer) <= RxIndex)
    {
        RxIndex = 0;
        fullFrame = true;
    }
    TMR6_WriteTimer(0); 
}

//void Interrupcao_EUSART_Rx(){
//    TMR6_StartTimer();
//    TMR6_WriteTimer(0);
//    uint8_t buffer_RX = EUSART_Read();
//    static uint8_t contador = 0;
//    if (contador == 0){
//    
//        DataRx.modo = buffer_RX;
//        contador++;
//        
//    }else{
//    
//        switch(DataRx.modo){
//            case 0:
//                if(contador == 1){
//                
//                }else if(contador = 2){
//                
//                }else if(){
//                
//                }
//                
//            break;
//            
//            case 1:
//                
//            break;
//            
//            case 2:
//                
//            break;
//            
//            default:
//                break;
//
//        
//        
//        
//        
//        }
//        
//    
//    }
//}
//Fun��o similiar ao An�lise_Rx()
void ProcessaDados(){
    
    // Array de ponteiros
   uint8_t *members[] = {
        &DataRx.modo, &DataRx.SpAlt_H, &DataRx.SpAlt_L,
        &DataRx.Vent_H, &DataRx.Vent_L, &DataRx.Pwm_H, &DataRx.Pwm_L
    };

    // Copiando os dados do array para os membros da struct usando o array de ponteiros
    for (int i = 0; i < 7; i++) {
        *members[i] = RxBuffer[i];
    }
    fullFrame = false;
    
    switch(DataRx.modo){
       case 0: 
           //fun��o enviar dados motor de passo, PWM
           //flag para entrar na fun��o do motor de passo e PWM
           // n�o vai utilizar a fun��o de controle.
          
          
           //SetPWM(Pwm_H,Pwm_L);
          // proximaPosicao = Vent_H e Vent_L;
           modoControle = 0;
       break;
       case 1: 
           // fun��o para setar um valor do passo e o controle ira�ajustar o PWM para atingir o set point de altura
          // PI = true;
           // proximaPosicao = Vent_H e Vent_L;
           // Setpoint = SpAlt_H e SpAlt_L;
           modoControle = 1;
           break;
       case 2: 
            // fun��o para setar um valor do PWM e o controle ira�ajustar a ventoinha para atingir o set point de altura
           //SetPWM(Pwm_H,Pwm_L);
           // Setpoint = SpAlt_H e SpAlt_L;
           modoControle = 1;
       break;
       case 3: 
           RESET(); // Reinicia o PIC
       break;
    }
}
//Transmiss�o    
void EnviaTX(){
       
    usartBuffer[0]  = modo;
    usartBuffer[1]  = DataRx.SpAlt_H;    //Setpoint
    usartBuffer[2]  = DataRx.SpAlt_L;   //Setpoint
    usartBuffer[3]  = D_mm.b1;   //Parte Alta da Medi��o da altura; 
    usartBuffer[4]  = D_mm.b0;   //Parte Baixa da Medi��o da altura;
    usartBuffer[5]  = contagem_temporizador.b1;          //Valor M�dio assumindo que a resposta tem que ser em bits;
    usartBuffer[6]  = contagem_temporizador.b0;          //Valor M�dio assumindo que a resposta tem que ser em bits;
    usartBuffer[7]  = temperatura.b1 * 10;
    usartBuffer[8]  = temperatura.b0 * 10;
    usartBuffer[9]  = DataRx.Vent_H; //Setpoint da V�lvula
    usartBuffer[10] = DataRx.Vent_L;
    usartBuffer[11] = (posicaoValvula & 0xFF00) >> 8; //M�scara para pegar a parte alta da posi��o da v�lvula 
    usartBuffer[12] = (posicaoValvula & 0x00FF);//M�scara para pegar a parte baixa da posi��o da v�lvula 
    usartBuffer[13] = DataRx.Pwm_H;
    usartBuffer[14] = DataRx.Pwm_L;
            
    for(uint8_t i; i<16; i++){
        EUSART_Write(usartBuffer[i]);
    }
    
}

void ReiniciaQuadro(){
    RxIndex = 0;
}

void Maquina(){
    
            //Temperatura e Velocidade
    
            //Posi��o 
        
            //Calcular a  m�dia  das ultimas quatro medi�oes
        
            //Controle
            //Verificar a flag de controlcase 3: 
            //Atualizar  o bufferTXe
         
            //Atualizar  o bufferTX
    }

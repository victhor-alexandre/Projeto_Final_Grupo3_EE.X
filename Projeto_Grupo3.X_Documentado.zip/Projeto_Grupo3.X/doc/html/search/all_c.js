var searchData=
[
  ['saidaanterior_0',['SaidaAnterior',['../main_8h.html#a4a61335ca356875982ad6e64aa71470a',1,'main.h']]],
  ['saidacontrolador_1',['SaidaControlador',['../main_8h.html#a6cf60bf6d26d0bc694fb9bd246275b0a',1,'main.h']]],
  ['setpoint_2',['Setpoint',['../main_8h.html#acfa3eadc9e2b75063b1026b5a111ab02',1,'main.h']]],
  ['setpwm_3',['setPwm',['../funcoes_8c.html#a063771cf1151a43b82670746411cedfd',1,'setPwm(uint16_t dutyValue):&#160;funcoes.c'],['../funcoes_8h.html#a063771cf1151a43b82670746411cedfd',1,'setPwm(uint16_t dutyValue):&#160;funcoes.c']]],
  ['sinal_4',['sinal',['../main_8h.html#a8e922cd3fb1a3e9d5624a9d939ac2285',1,'main.h']]]
];

var searchData=
[
  ['max_5fpasso_0',['MAX_PASSO',['../main_8h.html#ac532e178eee94d4b2dba344b7a098c8d',1,'main.h']]]
];

#include <xc.h>
#include "mcc_generated_files/mcc.h"
#include "main.h"
#include "funcoes.h"


void setPwm(uint16_t dutyValue)
{                                //< Recebe o valor do pwm
    EPWM1_LoadDutyValue(dutyValue);                             //< Carrega o Ciclo �til atrav�s da Fun��o
}


//------------------------------------------------------------------------------------------------------------------------------------
// Controle do motor de passo
//----------------------------------
// O motor de passo ser� controlado pela interrup��o de um timer de 5ms.
// Cada interrup��o, o controlador verifica se o motor j� chegou na posi��o desejada, e se n�o, avan�a um �nico passo na dire��o em quest�o
// Necess�rio 1 controle de dire��o, um contador, um booleano para inicializar o motor.

void interrupt_MotorDePasso(void)
{                                                               //< Ativado a cada 5ms
    static uint16_t posicaoValvulaReset = MAX_PASSO;            //< Essa vari�vel ser� decrementada e enviada ao motor de passo, at� que ele desative o sensor
    if(!resetPasso){                                            //< Se o reset estiver habilitado (resetPasso = 1))
        if(!CMP1_GetOutputStatus()){                            //< Se o sensor estiver em 1
            Passo(posicaoValvulaReset, 0);                      //< D� um passo para abrir a valvula
            posicaoValvulaReset--;
        }else{                                                  //< Se o sensor estiver em 0
            resetPasso = 1;                                     //< Desliga o reset
            posicaoValvula = 0;                                 //< Agora a posi��o padr�o � zerada
            posicaoValvulaReset = MAX_PASSO;                    //< Essa variavel � resetada em 450 para um futuro reset
        }
    }else{                                                      //< Se o reset estiver desabilitado
        if (proximaPosicao > MAX_PASSO) proximaPosicao = MAX_PASSO;                                                        //< Atualiza a posicao atual da v�lvula e depois d� um passo.
        if (proximaPosicao < 0) proximaPosicao = 0;                                                        //< Atualiza a posicao atual da v�lvula e depois d� um passo.
        if(posicaoValvula > proximaPosicao){
            if(posicaoValvula>0) posicaoValvula--;
        }else if (posicaoValvula < proximaPosicao){
            if(posicaoValvula<MAX_PASSO) posicaoValvula++;
        }
        
        Passo(posicaoValvula, proximaPosicao);                  //< D� um passo de acordo com as posi��es atuais e desejada
    }
    
    Medicao_Distancia_Trigger();                                //< Ativando o trigger uma vez a cada passo do motor de passo (a cada 5 ms)
}                                

void Passo(uint16_t posicaoAtual, uint16_t posicaoDesejada)
{
    static uint8_t i;
    SM1_SetLow();
    SM2_SetLow();
    SM3_SetLow();
    SM4_SetLow();
    
    if(posicaoAtual > posicaoDesejada){
        i = (i<=0) ? 3 : (i-1);                     //< Decrementa i, se i = 0, ent�o volta para i=3
    }else if (posicaoAtual < posicaoDesejada){
        i = (i>=3) ? 0 : (i+1);                     //< Incrementa i, se i = 3, ent�o volta para i=0
    }else{
        i=4;                                        //< Se estiver na posi��o desejada, n�o entra em nenhum dos cases (o motor de passo fica desligado)
    }
    
    switch(i){
        case 3:
            SM1_SetHigh();
            SM2_SetHigh();
            break;
        case 2:
            SM2_SetHigh();
            SM3_SetHigh();
            break;
        case 1:
            SM3_SetHigh();
            SM4_SetHigh();
            break;
        case 0:
            SM4_SetHigh();
            SM1_SetHigh();
            break;
    }
    
}



//------------------------------------------------------------------------------------------------------------------------------------
// rotina de controle
//----------------------------------
// Modelo PI (proporcional-integrador)
// Deve controlar ou o pwm, ou o motor de passo
// faz parte da m�quina de estados. Ou seja, deve ser bypassed quando um dos modos de controle estiver inativo

void calcularErro(void)
{
    Erro = (int)(Setpoint - D_mm.Dado);        //Erro(k) = sp(K) - y(K)
}

void calcularSaidaControlador(void)
{
    SaidaControlador = ((sinal*Kc)*((Erro - Erro_1)+(T/Ti)*((Erro+Erro_1)/2)));     //< Calculando o incremento ou decremento do controlador
    SaidaControlador = SaidaControlador + SaidaAnterior;                            //< Somando o valor anterior

    if((int)(SaidaControlador) < 0){
        SaidaControlador = 0;                                                       //< Limitando valores menores que zero
    }else if((int)(SaidaControlador) > limite){
        SaidaControlador = limite;                                                  //< Limitando valores maiores que o limite do atuador (depende do modo de controle usado)
    }
    if(tipoControle){                                                               //< Modo de controle usado (0 = pwm, 1 = motor de passo)
        proximaPosicao = (uint16_t)(SaidaControlador);                              //< Aplica a sa�da do controlador no motor de passo
    }else{
        dutyValue = (uint16_t)(SaidaControlador);
        setPwm(dutyValue);                                                          //< Aplica a sa�da do controlador no PWM
    }
}

void guardarValoresDoControlador(void)
{
    Erro_1 = Erro;                              //< Atualiza o erro anterior para a pr�xima opera��o
    SaidaAnterior = SaidaControlador;           //< Atualiza a sa�da anterior para a pr�xima opera��o
}



//------------------------------------------------------------------------------------------------------------------------------------
// Aquisi�ao da Temperatura e Velocidade do Som
//----------------------------------
// Realiza-se a aquisi��o da Temperatura com uma precis�o de varia��o de 1�C.
// Com o valor da Temperatura � o valor correspondente da velocidade do som na tabela armazenada na Mem�ria EEPROM.
 
void Temperatura_e_VelocidadeSom()
{
    temp.Dado = (uint16_t)((ADC_GetConversion(8)));          //< temp = valor do adc x resolu��o ((50-2)/1024) + 273
    v_som = TUPVT[temp.Dado/10];                             //Para c�lculo da velocidade do som
}

// Essa fun��o � acionada ap�s a chegada da borda de descida do sinal de Echo
void Posicao_Bola_Tubo()
{   
    //Vari�vel respons�vel por transformar o tempo em unidades de engenharia (segundos)
    tempo_s = TMR1_ReadTimer();         //< Base de tempo em us (a cada incremento do timer corresponde a 1 us.)
    mediaTempo = Media(tempo_s);        //< Calcula a m�dia dos �ltimos 4 tempos medidos
    D_mm.Dado = (uint16_t)(((uint24_t)(v_som) * (uint24_t)(mediaTempo)) / 2000);  //< C�lculo da dist�ncia em mil�metros
    TMR1_WriteTimer(0);
    
}

// Essa fun��o � chamada a cada 5ms (dentro da interrup��o do motor de passo)
void Medicao_Distancia_Trigger(void)
{
    TRIGGER_SetHigh();      //< Ativa o trigger por 15 us
    __delay_us(15);
    TRIGGER_SetLow();       //< Desativa o Trigger
    
    flagControle = 1;       //< Flag que permite o calculo do controlador a cada 5 ms
        
}
//------------------------------------------------------------------------------------------------------------------------------------
// Comunica��o Serial RX e TX
//----------------------------------
// Recebimento de dados no quadro de comunica��o.
// 40 ms sem receber dados, reinicia o quadro.
// 7 Bytes de Recep��o e 15 Bytes de Transmiss�o
// A cada 100ms envia dados.
void EUSART_RxBuffer()
{
    uint8_t TempRx = RCREG;                             //< Armazeno o byte recebido em variavel temporaria
    if(sizeof(RxBuffer) > RxIndex)                      //< Verifico se o ponterio a posi��o do ponteiro no buffer de recep��o
    {
        RxBuffer[RxIndex++] = TempRx;                   //< Armazeno o valor recebido no buffer de recep��o
        TMR6_WriteTimer(0);                             //< Zero o Time para a contagem do tempo
    }
    if(RxIndex == sizeof(RxBuffer)){                    //< Verifico se o ponteiro armazenou dado na ultima posi��o do buffer de recep��o
        fullFrame = true;                               //< Ativo a flag de quadro completo
        RxIndex = 0;                                    //< Reinicio o ponteiro do buffer de localiza��o
    }
    
}

void ProcessaDados()
{
    RxIndex = 0;
    if(!fullFrame){         
        return;
    }
    
    modo = RxBuffer[0];
    if ((modo >= 0) | (modo<=3)){                           //< s� carrega as vari�veis com os Buffers se o comando for v�lido
        Setpoint          =(RxBuffer[1] << 8)| RxBuffer[2];   
        proximaPosicao    =(RxBuffer[3] << 8)| RxBuffer[4];
        dutyValue         =(RxBuffer[5] << 8)| RxBuffer[6];
    }
    fullFrame = false;
    
    switch(modo){
        case 0:                     //< fun��o manual (apenas ativa o pwm e o motor de passo no valor recebido)
            setPwm(dutyValue);
            modoControle = 0;       //< Modo de controle desativado
            Setpoint = 0;           //< Desprezando o setpoint recebido pelo eusart
        break;
        
        case 1:                     //< Fun��o para setar um valor do passo e o controle ir� ajustar o PWM para atingir o set point de altura
            dutyValue = 0;          //< Zerando o duty value que foi escrito na recep��o do EUSART
            SaidaAnterior = 0;      //< Ocontrolador come�a com a sa�da em 0
            modoControle = 1;       //< Controlador ativado
            tipoControle = 0;       //< Modo de controle do pwm
            break;
            
        case 2:                     //< Fun��o para setar um valor do PWM e o controle ira�ajustar a ventoinha para atingir o set point de altura
            setPwm(dutyValue);
            proximaPosicao = 0;     //< Zerando a posi��o do passo que foi escrita na recep��o do EUSART
            SaidaAnterior = 0;      //< O controlador come�a com a sa�da em 0
            modoControle = 1;       //< Controlador ativado
            tipoControle = 1;       //< Modo de controle do motor de passo
            break;
        
        case 3: 
            RESET();                //< Reinicia o PIC
            break;
            
        default:                    //< Se chega um modo inv�lido, n�o faz nada
            break;
    }
}
    
void EnviaTX()
{
    for(uint8_t i=0; i<15; i++){
        EUSART_Write(TxBuffer[i]);      //< Transmite os 15 bytes do buffer de transmiss�o
    }
   
}

void EUSART_TxBuffer()
{
    
    TxBuffer[0] = modo;                             //< Modo de Opera��o 
    TxBuffer[1] = (Setpoint & 0xFF00) >> 8;         //< Setpoint de Altura.b1
    TxBuffer[2] = (Setpoint & 0x00FF);              //< SetPoint de Altura.b0
    TxBuffer[3] = D_mm.b1;                          //< Medi�ao de altura.b1
    TxBuffer[4] = D_mm.b0;                          //< Medi�ao de altura.b0
    TxBuffer[5] = (mediaTempo & 0xFF00) >> 8;       //< Tempo.b1
    TxBuffer[6] = (mediaTempo & 0x00FF) ;           //< Tempo.b0
    TxBuffer[7] = temp.b1;                          //< Temperatura.b1
    TxBuffer[8] = temp.b0;                          //< Temperatura.b0
    TxBuffer[9] = (proximaPosicao & 0xFF00) >> 8;   //< Setpoint de Valvula.b1
    TxBuffer[10] = (proximaPosicao & 0x00FF);       //< Setpoint de Valvula.b0
    TxBuffer[11] = (posicaoValvula & 0xFF00) >> 8;  //< Posi��o Valvula.b1
    TxBuffer[12] = (posicaoValvula & 0x00FF);       //< Posi��o Valvula.b0
    TxBuffer[13] = (dutyValue & 0xFF00) >> 8 ;      //< Ciclo Util Motor.b1
    TxBuffer[14] = (dutyValue & 0x00FF);            //< Ciclo Util Motor.b0
}



//------------------------------------------------------------------------------------------------------------------------------------
// M�quina de Estado Finito 
//----------------------------------
// Atua��o nos modos de Opera��o

void Maquina()
{
    Temperatura_e_VelocidadeSom();          //< Calcular a velocidade do som com a temperatura medida
    
    if(modoControle & flagControle){        //< Executa a rotina de controle, caso o modo de controle e a flag estejam ativas
        calcularErro();
        calcularSaidaControlador();
        guardarValoresDoControlador();
        flagControle = 0;                   //< Zerando a flag para s� calcular ap�s a pr�xima medi��o de dist�ncia
    }
    
    EUSART_TxBuffer();                      //< Atualiza o buffer de transmiss�o
}


uint16_t Media(uint16_t Time)
{              
    static uint8_t i=0;                     //< Contador para a m�dia
    uint16_t Media;
    static uint16_t bufferTempo[4];         //< Buffer das quatro �ltimas medidas de tempo
    i = (i==3) ? 0 : (i+1);                 //< O contador rotaciona entre 0 e 3, incrementando 1 ou voltando para zero a cada vez 
    bufferTempo[i] = Time;                  //< Cada buffer � atualizado a cada quarta vez que essa fun��o � chamada
    Media = (bufferTempo[0] + bufferTempo[1] + bufferTempo[2] + bufferTempo[3])/4;  //< Calcula a m�dia
    return Media;                           //< Retorna a m�dia
}
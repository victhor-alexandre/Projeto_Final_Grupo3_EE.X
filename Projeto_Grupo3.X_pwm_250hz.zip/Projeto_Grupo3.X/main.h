/* 
 * File:                main.h  
 * Author:              Herbert Tavares, Julio Cesar Carvalhes, Victhor Alexandre, Yuri Virginio
 * Comments:            -- // --
 * Revision history:    2.00
 */

#ifndef XC_HEADER_TEMPLATE_H
#define	XC_HEADER_TEMPLATE_H

#include <xc.h> ///< include processor files - each processor file is guarded.

//Definindo Constantes-----------------------------------------------------------------------------------------------------------------
#define Kc ((tipoControle) ? (0.0065) : (0.00065))    ///< Ganho do controlador (definido para cada tipo de controle)
#define T ((tipoControle) ? (1) : (1))        ///< Per�odo do controlador (definido para cada tipo de controle)
#define Ti ((tipoControle) ? (0.3) : (0.63))       ///< Tempo de integra��o (definido para cada tipo de controle)
#define MAX_PASSO 450                           //< N�mero m�ximo de passos do motor.

//Definindo Operadores Tern�rios-------------------------------------------------------------------------------------------------------
#define limite ((tipoControle) ? ((uint16_t)MAX_PASSO) : (1023))    ///< Limite da sa�da do controlador (definido para cada tipo de controle)
#define sinal  ((tipoControle) ? -1 : 1)            ///< Sinal aplicado ao controlador (1 = controle direto, -1 = controle inverso)     
//como o motor de passo segue opera��o inversa (para aumentar o fluxo de ar, diminui-se a posi��o da v�lvula)
//ent�o invertemos o sinal de Kp com essa vari�vel, de acordo com o modo de opera��o


//Estrutura de dados (Union)-----------------------------------------------------------------------------------------------------------
/**
 * Estrutura para dados usada para separar 2 bytes
 */
union{                             //< Uni�o entre 2 bytes de dados.
    uint16_t Dado;                 ///< Valor de 16 bits que contem os bytes b1 e b0.
    struct{
        uint8_t b0;                ///< Byte b0 LSB 
        uint8_t b1;                ///< Byte b1 MSB
    };
}D_mm,                  ///< Posi��o (em mil�metros)
temp;                   ///< Temperatura (em graus Celsius)

//Variaveis Globais-------------------------------------------------------------------------------------------------------------------

bool            fullFrame = false,              ///< Flag do quadro de comunica��o de Recep��o Completa
                resetPasso = 0,                 ///< Flag para resetar a posi��o da Valvula
                flagControle,                   ///< Flag que ativa o controle a cada medi��o de dist�ncia
                modoControle,                   ///< 0 = controle desativado, 1 = controle ativado
                tipoControle;                   ///< 0 = controle do pwm, 1 = controle do motor de passo

float           SaidaControlador=0,             ///< Valor calculado pelo controlador
                SaidaAnterior=0;                ///< Valor do controlador no c�lculo do ciclo aterior
                

uint16_t        posicaoValvula,                 ///< Posi��o atual do motor de passo
                proximaPosicao,                 ///< Posi��o que se deseja no motor de passo
                dutyValue,                      ///< Valor de largura de pulso do PWM
                Setpoint,                       ///< Valor de altura desejado pelo controlador
                tempo_s = 0,                    ///< Tempo medido pelo sinal do Echo
                v_som,                          ///< Velocidade do som compensada pela temperatura
                mediaTempo;                     ///< M�dia do tempo dos quatro �ltimos sinais do Echo

int             Erro    = 0,                    ///< Erro calculado no Controle P.I. 
                Erro_1  = 0;                    ///< Erro calculado na opera��o anterior 
                

uint8_t         TxBuffer[15],                   ///< Buffer de Transmiss�o USART
                RxBuffer[7],                    ///< Buffer de Recep��o USART
                modo,                           ///< Modo de Opera��o
                RxIndex=0;                      ///< Ponteiro do Buffer de Recep��o

         
//Mem�ria EEPROM -----------------------------------------------------------------------------------------------------------------
/**
 * Tabela de Velocidades do Som correspondentes �s Temperaturas de 0�C a 50�C 
 */
__eeprom uint16_t TUPVT[] = {
    331, 332, 333, 333, 334, 334, 335, 336, 336, 337, 
    337, 338, 339, 339, 340, 340, 341, 342, 342, 343, 
    343, 344, 345, 345, 346, 346, 347, 347, 348, 349, 
    349, 350, 350, 351, 351, 352, 353, 353, 354, 354, 
    355, 355, 356, 357, 357, 358, 358, 359, 359, 360, 
    361
};

#endif	/* XC_HEADER_TEMPLATE_H */


var searchData=
[
  ['limite_0',['limite',['../main_8h.html#a719a2abf970ccb02be299e6824150b1c',1,'main.h']]]
];

var searchData=
[
  ['d_5fmm_0',['D_mm',['../main_8h.html#a280ff121f6346e4110a497caf0f7eb2a',1,'main.h']]],
  ['dado_1',['Dado',['../main_8h.html#ae72d7d11655aa39587d23e75693cfcdf',1,'main.h']]],
  ['dutyvalue_2',['dutyValue',['../main_8h.html#ad9c859be31990a7ed2109e09cdaccd8c',1,'main.h']]]
];

var searchData=
[
  ['temperatura_5fe_5fvelocidadesom_0',['Temperatura_e_VelocidadeSom',['../funcoes_8c.html#a005ef4e773a3df9c845532d2ae9a14e9',1,'Temperatura_e_VelocidadeSom():&#160;funcoes.c'],['../funcoes_8h.html#ad99006d02437615dac83b2c2bdb34628',1,'Temperatura_e_VelocidadeSom(void):&#160;funcoes.c']]]
];

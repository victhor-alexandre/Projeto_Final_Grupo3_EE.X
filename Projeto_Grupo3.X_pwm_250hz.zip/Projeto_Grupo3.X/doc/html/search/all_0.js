var searchData=
[
  ['b0_0',['b0',['../main_8h.html#a9428f4229e2203fa643916ca52a3e663',1,'main.h']]],
  ['b1_1',['b1',['../main_8h.html#ac252074002fd2018498430cf078d3c48',1,'main.h']]]
];

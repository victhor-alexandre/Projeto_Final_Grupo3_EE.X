var searchData=
[
  ['calcularerro_0',['calcularErro',['../funcoes_8c.html#aa6fc79527cd9297df8d7fc1e574c8c68',1,'calcularErro(void):&#160;funcoes.c'],['../funcoes_8h.html#aa6fc79527cd9297df8d7fc1e574c8c68',1,'calcularErro(void):&#160;funcoes.c']]],
  ['calcularsaidacontrolador_1',['calcularSaidaControlador',['../funcoes_8c.html#aa2c59fb0269326fc4f29d5b454d3c758',1,'calcularSaidaControlador(void):&#160;funcoes.c'],['../funcoes_8h.html#aa2c59fb0269326fc4f29d5b454d3c758',1,'calcularSaidaControlador(void):&#160;funcoes.c']]]
];

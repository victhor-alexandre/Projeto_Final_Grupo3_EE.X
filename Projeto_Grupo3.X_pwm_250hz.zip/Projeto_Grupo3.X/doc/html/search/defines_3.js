var searchData=
[
  ['sinal_0',['sinal',['../main_8h.html#a8e922cd3fb1a3e9d5624a9d939ac2285',1,'main.h']]]
];
